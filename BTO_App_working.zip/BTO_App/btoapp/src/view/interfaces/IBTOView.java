package view.interfaces;

public interface IBTOView extends ViewInterface {
    void refreshData();
    boolean handleNavigation(int option);
}