package model.interfaces;

public interface IApplicant {

}
